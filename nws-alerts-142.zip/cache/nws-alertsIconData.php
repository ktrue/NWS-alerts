<?php 
$bigIcons = array (
  1 => ' <a href="nws-details.php?a=IAZ091#WA1" title=" &nbsp;Details for Page&nbsp;Red Flag Warning" style="width:99%; text-decoration:none; padding-top:3px">Page<br /><img src="./alert-images/A-warn.png" alt=" &nbsp;Details for Page&nbsp;Red Flag Warning" width="74" height="18" style="border:none; padding-bottom:3px" /><br /></a>
',
  2 => ' <a href="nws-details.php?a=IAZ091#WA3" title=" &nbsp;Details for Page&nbsp;Wind Advisory" style="width:99%; text-decoration:none; padding-top:3px">Page<br /><img src="./alert-images/A-advisory.png" alt=" &nbsp;Details for Page&nbsp;Wind Advisory" width="74" height="18" style="border:none; padding-bottom:3px" /><br /></a>
',
  3 => ' <a href="nws-details.php?a=IAZ091#WA4" title=" &nbsp;Details for Page&nbsp;Tornado Watch" style="width:99%; text-decoration:none; padding-top:3px">Page<br /><img src="./alert-images/A-watch.png" alt=" &nbsp;Details for Page&nbsp;Tornado Watch" width="74" height="18" style="border:none; padding-bottom:3px" /><br /></a>
',
  4 => ' <a href="nws-details.php?a=IAZ091#WA2" title=" &nbsp;Details for Page&nbsp;Fire Weather Watch" style="width:99%; text-decoration:none; padding-top:3px">Page<br /><img src="./alert-images/A-watch.png" alt=" &nbsp;Details for Page&nbsp;Fire Weather Watch" width="74" height="18" style="border:none; padding-bottom:3px" /><br /></a>
',
  5 => ' <a href="nws-details.php?a=CAZ529#WA1" title=" &nbsp;Details for Santa Cruz&nbsp;" style="width:99%; text-decoration:none; padding-top:3px">Santa Cruz<br /><img src="./alert-images/A-none.png" alt=" &nbsp;Details for Santa Cruz&nbsp;" width="74" height="18" style="border:none; padding-bottom:3px" /><br /></a>
',
);
?>
