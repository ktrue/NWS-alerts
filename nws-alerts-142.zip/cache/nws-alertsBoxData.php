<?php 
$alertBox = '
<!-- nws-alerts box -->
<div style="width:99%; border:solid thin #000; margin:0px auto 0px auto;">
 <div style=" background-color:#CC0000; text-align:center; color: white; padding:4px 8px 4px 8px">
  <span style="white-space: nowrap">&nbsp;<a href="nws-details.php?a=IAZ091" style="color: white; text-decoration: none" title=" &nbsp;View details"><b>Page</b></a></span>&nbsp;&nbsp;-<span style="white-space: nowrap">&nbsp; <img src="./alert-images/FWW.gif" width="12" height="12" alt="Red Flag Warning" title=" Red Flag Warning" />&nbsp;<a href="nws-details.php?a=IAZ091#WA1" style="color: white; text-decoration: none" title=" &nbsp;Details for Page - Red&nbsp;Flag&nbsp;Warning">Red&nbsp;Flag&nbsp;Warning</a>&nbsp;&nbsp;</span> <span style="white-space: nowrap">&nbsp; <img src="./alert-images/WIY.gif" width="12" height="12" alt="Wind Advisory" title=" Wind Advisory" />&nbsp;<a href="nws-details.php?a=IAZ091#WA3" style="color: white; text-decoration: none" title=" &nbsp;Details for Page - Wind&nbsp;Advisory">Wind&nbsp;Advisory</a>&nbsp;&nbsp;</span> <span style="white-space: nowrap">&nbsp; <img src="./alert-images/TOA.gif" width="12" height="12" alt="Tornado Watch" title=" Tornado Watch" />&nbsp;<a href="nws-details.php?a=IAZ091#WA4" style="color: white; text-decoration: none" title=" &nbsp;Details for Page - Tornado&nbsp;Watch">Tornado&nbsp;Watch</a>&nbsp;&nbsp;</span> <span style="white-space: nowrap">&nbsp; <img src="./alert-images/FWA.gif" width="12" height="12" alt="Fire Weather Watch" title=" Fire Weather Watch" />&nbsp;<a href="nws-details.php?a=IAZ091#WA2" style="color: white; text-decoration: none" title=" &nbsp;Details for Page - Fire&nbsp;Weather&nbsp;Watch">Fire&nbsp;Weather&nbsp;Watch</a>&nbsp;&nbsp;</span> <br />
 </div>
</div>
';

?>