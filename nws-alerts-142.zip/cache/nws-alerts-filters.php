<?php 
 
$dsrgrd = array (
  'teoe' => '911 Telephone Outage',
  'toee' => '911 Telephone Outage Emergency',
//  'sest' => 'Special Weather Statement',
);

$filtered_alerts = '^911 Telephone Outage|^911 Telephone Outage Emergency';

?>